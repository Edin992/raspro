<?php
/**
 * admin/includes/footer.php - Admin footer
 */
?>
    </div>
</main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/admin/assets/js/admin.js"></script>
</body>
</html>